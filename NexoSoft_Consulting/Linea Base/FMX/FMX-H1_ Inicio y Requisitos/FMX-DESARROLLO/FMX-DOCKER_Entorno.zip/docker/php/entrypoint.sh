#!/bin/bash
# ───────────────────────────────────────────────────────────────────────────
#  FERREMAX · Punto de entrada del contenedor de aplicación
#  Prepara los permisos de Laravel y espera a que MySQL acepte conexiones
#  antes de ceder el control a php-fpm.
# ───────────────────────────────────────────────────────────────────────────
set -e

APP_DIR=/var/www/html

# Carpetas que Laravel necesita poder escribir
if [ -d "$APP_DIR/storage" ]; then
    mkdir -p "$APP_DIR/storage/framework/"{cache,sessions,testing,views} \
             "$APP_DIR/storage/logs" \
             "$APP_DIR/bootstrap/cache" 2>/dev/null || true
    chmod -R ug+rw "$APP_DIR/storage" "$APP_DIR/bootstrap/cache" 2>/dev/null || true
fi

# Espera a la base de datos (hasta 60 s) para que las migraciones no fallen
# por arrancar antes que MySQL.
if [ -n "${DB_HOST}" ]; then
    echo "[ferremax] Esperando a la base de datos en ${DB_HOST}:${DB_PORT:-3306} ..."
    for i in $(seq 1 60); do
        if mysqladmin ping -h"${DB_HOST}" -P"${DB_PORT:-3306}" --silent 2>/dev/null; then
            echo "[ferremax] Base de datos disponible."
            break
        fi
        sleep 1
    done
fi

exec "$@"
