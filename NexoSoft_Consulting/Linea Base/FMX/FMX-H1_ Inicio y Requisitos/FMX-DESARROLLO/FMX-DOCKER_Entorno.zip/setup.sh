#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
#  FERREMAX · Instalación del entorno de desarrollo
#
#  Deja el proyecto listo para trabajar: construye las imágenes, levanta los
#  contenedores, instala Laravel 11 si aún no existe, configura la conexión a
#  MySQL y ejecuta las migraciones.
#
#  Uso:   bash setup.sh
#  Es seguro volver a ejecutarlo: no sobrescribe un proyecto ya instalado.
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail

ROJO='\033[0;31m'; VERDE='\033[0;32m'; AZUL='\033[0;34m'; AMAR='\033[0;33m'; FIN='\033[0m'
paso()  { echo -e "\n${AZUL}▶ $1${FIN}"; }
ok()    { echo -e "${VERDE}  ✓ $1${FIN}"; }
aviso() { echo -e "${AMAR}  ! $1${FIN}"; }
error() { echo -e "${ROJO}  ✗ $1${FIN}"; exit 1; }

DC="docker compose"

# ── 1. Comprobaciones previas ────────────────────────────────────────────────
paso "Comprobando requisitos"
command -v docker >/dev/null 2>&1 || error "Docker no está instalado. Instale Docker Desktop y vuelva a intentarlo."
docker compose version >/dev/null 2>&1 || error "No se encontró «docker compose». Actualice Docker Desktop."
docker info >/dev/null 2>&1 || error "El servicio de Docker no está en ejecución. Abra Docker Desktop y espere a que arranque."
ok "Docker $(docker --version | awk '{print $3}' | tr -d ,) operativo"

# ── 2. Variables del entorno ─────────────────────────────────────────────────
paso "Preparando las variables del entorno"
if [ ! -f .env ] && [ -f .env.docker.example ]; then
    cp .env.docker.example .env
    # UID y GID reales del usuario, para que los archivos no queden como root
    if [ "$(uname)" != "Darwin" ] || true; then
        sed -i.bak "s/^UID=.*/UID=$(id -u)/"  .env 2>/dev/null || true
        sed -i.bak "s/^GID=.*/GID=$(id -g)/"  .env 2>/dev/null || true
        rm -f .env.bak
    fi
    ok "Archivo .env creado a partir de .env.docker.example"
else
    ok "Ya existe un archivo .env; se conserva tal cual"
fi

# ── 3. Construcción de las imágenes ──────────────────────────────────────────
paso "Construyendo las imágenes (la primera vez puede tardar varios minutos)"
$DC build
ok "Imágenes construidas"

# ── 4. Base de datos ─────────────────────────────────────────────────────────
paso "Levantando la base de datos"
$DC up -d db
echo -n "  esperando a MySQL"
for _ in $(seq 1 60); do
    estado=$(docker inspect --format='{{.State.Health.Status}}' ferremax_db 2>/dev/null || echo "starting")
    [ "$estado" = "healthy" ] && break
    echo -n "."
    sleep 2
done
echo ""
[ "${estado:-}" = "healthy" ] || error "MySQL no llegó a estar disponible. Revise: docker compose logs db"
ok "MySQL 8.0 disponible"

# ── 5. Proyecto Laravel ──────────────────────────────────────────────────────
paso "Verificando el proyecto Laravel"
if [ ! -f artisan ]; then
    aviso "No se encontró el proyecto; se instalará Laravel 11"
    $DC run --rm --no-deps app bash -lc '
        set -e
        composer create-project laravel/laravel:^11.0 /tmp/laravel --no-interaction --prefer-dist
        # Copia sin sobrescribir los archivos del entorno ya versionados
        cp -rn /tmp/laravel/. /var/www/html/
        rm -rf /tmp/laravel
    '
    ok "Laravel 11 instalado"
else
    ok "El proyecto ya está instalado"
fi

# ── 6. Configuración de Laravel ──────────────────────────────────────────────
paso "Configurando la conexión a la base de datos"
$DC run --rm --no-deps app bash -lc '
    set -e
    [ -f .env ] || cp .env.example .env

    poner() {  # poner CLAVE valor
        if grep -qE "^#?\s*$1=" .env; then
            sed -i "s|^#\?\s*$1=.*|$1=$2|" .env
        else
            echo "$1=$2" >> .env
        fi
    }

    poner APP_NAME        FERREMAX
    poner APP_ENV         local
    poner APP_DEBUG       true
    poner APP_URL         http://localhost:${APP_PORT:-8080}
    poner APP_TIMEZONE    America/Lima
    poner APP_LOCALE      es

    poner DB_CONNECTION   mysql
    poner DB_HOST         db
    poner DB_PORT         3306
    poner DB_DATABASE     "${DB_DATABASE:-ferremax}"
    poner DB_USERNAME     "${DB_USERNAME:-ferremax}"
    poner DB_PASSWORD     "${DB_PASSWORD:-ferremax}"

    poner SESSION_DRIVER  database
    poner CACHE_STORE     database
    poner QUEUE_CONNECTION database

    # Variables del entorno de contenedores, en el mismo .env
    grep -q "^APP_PORT="  .env || echo "APP_PORT=${APP_PORT:-8080}"   >> .env
    grep -q "^PMA_PORT="  .env || echo "PMA_PORT=${PMA_PORT:-8081}"   >> .env
    grep -q "^DB_ROOT_PASSWORD=" .env || echo "DB_ROOT_PASSWORD=${DB_ROOT_PASSWORD:-root}" >> .env
'
ok "Archivo .env de Laravel configurado"

# ── 7. Dependencias y clave de aplicación ────────────────────────────────────
paso "Instalando dependencias"
$DC run --rm --no-deps app bash -lc '
    set -e
    [ -d vendor ] || composer install --no-interaction --prefer-dist
    grep -qE "^APP_KEY=base64:" .env || php artisan key:generate --force
'
ok "Dependencias de PHP instaladas y clave de aplicación generada"

# ── 8. Contenedores completos ────────────────────────────────────────────────
paso "Levantando todos los contenedores"
$DC up -d
sleep 3
ok "Contenedores en ejecución"

# ── 9. Migraciones ───────────────────────────────────────────────────────────
paso "Ejecutando las migraciones"
$DC exec -T app php artisan migrate --force
ok "Base de datos migrada"

# ── 10. Assets ───────────────────────────────────────────────────────────────
paso "Compilando los assets del frontend"
if $DC exec -T app bash -lc '[ -f package.json ]'; then
    $DC exec -T app bash -lc 'npm install --no-audit --no-fund && npm run build' \
        || aviso "No se pudieron compilar los assets. Ejecute «make assets» más tarde."
    ok "Assets compilados"
fi

# ── Resumen ──────────────────────────────────────────────────────────────────
PUERTO=$(grep -E "^APP_PORT=" .env 2>/dev/null | cut -d= -f2 || echo 8080)
PMA=$(grep -E "^PMA_PORT=" .env 2>/dev/null | cut -d= -f2 || echo 8081)
cat <<RESUMEN

$(echo -e "${VERDE}")─────────────────────────────────────────────────────────────
  FERREMAX · entorno listo
─────────────────────────────────────────────────────────────$(echo -e "${FIN}")

  Aplicación    http://localhost:${PUERTO:-8080}
  phpMyAdmin    http://localhost:${PMA:-8081}    (usuario: ferremax · clave: ferremax)

  Contenedores  ferremax_nginx · ferremax_app · ferremax_db · ferremax_pma

  Comandos útiles
    make estado     ver el estado de los contenedores
    make shell      entrar al contenedor de la aplicación
    make migrar     ejecutar migraciones
    make logs       ver los registros
    make down       detener el entorno

RESUMEN
