# FERREMAX — Sistema Web de Gestión para Ferretería

Entorno de desarrollo en contenedores. Corresponde a la actividad **H1.4 ·
Configuración del entorno Docker (app, nginx, db) y docker-compose** del Hito 1.

| | |
|---|---|
| Proyecto | FERREMAX (FMX) |
| Curso | Diseño de Software · UNMSM · FISI · E.P. de Ingeniería de Software |
| Grupo | Grupo 2 |
| Responsable del entorno | Mallqui Meza |
| Stack | PHP 8.2 · Laravel 11 · MySQL 8.0 · Nginx · Bootstrap 5.3 · Chart.js |

---

## Requisitos previos

Solo hace falta **Docker Desktop** (Windows o macOS) o **Docker Engine con el
plugin Compose** (Linux). No instale PHP, Composer, MySQL ni Node en su máquina:
todo corre dentro de los contenedores.

Compruébelo con:

```bash
docker --version
docker compose version
```

---

## Instalación

```bash
git clone https://github.com/grupo2-unmsm/ferremax.git
cd ferremax
bash setup.sh
```

El script hace todo lo necesario: construye las imágenes, levanta MySQL, instala
Laravel 11 si aún no está, configura la conexión a la base de datos, genera la
clave de aplicación, ejecuta las migraciones y compila los assets.

Al terminar tendrá:

| Servicio | Dirección |
|---|---|
| Aplicación | <http://localhost:8080> |
| phpMyAdmin | <http://localhost:8081> — usuario `ferremax`, clave `ferremax` |

> `setup.sh` se puede volver a ejecutar sin miedo: detecta lo que ya está hecho y
> no sobrescribe un proyecto instalado.

---

## Los cuatro contenedores

Reproducen el diagrama de despliegue del DAS (sección 6):

| Contenedor | Imagen | Función | Puerto |
|---|---|---|---|
| `ferremax_nginx` | nginx:1.27-alpine | Atiende las peticiones HTTP y sirve `public/` | 8080 → 80 |
| `ferremax_app` | build propio (php:8.2-fpm) | Ejecuta Laravel por FastCGI | 9000 (interno) |
| `ferremax_db` | mysql:8.0 | Base de datos, con volumen `db_data` | 3306 (interno) |
| `ferremax_pma` | phpmyadmin:5 | Consola para inspeccionar la base de datos | 8081 → 80 |

Los cuatro comparten la red interna `ferremax_net`. **La base de datos no publica
ningún puerto hacia el host**: solo es accesible desde la red de Docker, que es lo
que corresponde a un despliegue en la red local del establecimiento.

```
        host:8080                    host:8081
            │                            │
   ┌────────▼────────┐          ┌────────▼────────┐
   │ ferremax_nginx  │          │  ferremax_pma   │
   └────────┬────────┘          └────────┬────────┘
            │ FastCGI :9000              │
   ┌────────▼────────┐                   │
   │  ferremax_app   │───────────────────┤
   │  PHP-FPM 8.2    │                   │ :3306
   └────────┬────────┘                   │
            │                   ┌────────▼────────┐
            └──────────────────▶│  ferremax_db    │──▶ volumen db_data
                                │   MySQL 8.0     │
                                └─────────────────┘
                    red interna: ferremax_net
```

---

## Comandos del día a día

Con `make`:

```bash
make up        # levanta el entorno
make down      # lo detiene (la base de datos se conserva)
make estado    # muestra el estado de los contenedores
make logs      # registros en vivo
make shell     # terminal dentro del contenedor de la aplicación
make mysql     # cliente de MySQL
make migrar    # php artisan migrate
make fresh     # rehace la base de datos y carga datos de prueba
make test      # php artisan test
make assets    # compila los assets con Vite
make limpiar   # detiene y BORRA la base de datos
```

Sin `make`, los equivalentes directos:

```bash
docker compose up -d
docker compose down
docker compose ps
docker compose logs -f
docker compose exec app bash
docker compose exec app php artisan migrate
docker compose exec app npm run build
```

Cualquier comando de Artisan, Composer o npm se ejecuta **dentro** del contenedor:

```bash
docker compose exec app php artisan make:model Producto -mcr
docker compose exec app composer require barryvdh/laravel-dompdf
docker compose exec app npm install chart.js
```

---

## Estructura

```
ferremax/
├── docker-compose.yml          # Define los cuatro contenedores
├── setup.sh                    # Instalación en un solo comando
├── Makefile                    # Atajos de uso diario
├── .env.docker.example         # Plantilla de variables del entorno
├── .dockerignore
├── .gitignore
├── docker/
│   ├── php/
│   │   ├── Dockerfile          # Imagen de la aplicación
│   │   ├── php.ini             # Ajustes de PHP
│   │   └── entrypoint.sh       # Permisos y espera a MySQL
│   ├── nginx/
│   │   └── default.conf        # Virtual host
│   └── mysql/
│       └── my.cnf              # utf8mb4, modo estricto, zona horaria
└── ... (aquí vive el proyecto Laravel: app/, database/, resources/, routes/)
```

---

## Decisiones del entorno y por qué

**El usuario del contenedor no es root.** El `Dockerfile` recibe el UID y el GID
de quien ejecuta y crea un usuario equivalente. Sin esto, en Linux y macOS los
archivos que genera Laravel (`storage/`, `bootstrap/cache/`) quedarían como root
y no se podrían editar desde el editor.

**MySQL tiene `healthcheck` y los demás lo esperan.** `app` y `phpmyadmin`
declaran `depends_on: condition: service_healthy`. Sin eso, Laravel arranca antes
que la base de datos y las migraciones fallan la primera vez.

**El modo estricto de MySQL está activado** (`sql_mode = STRICT_TRANS_TABLES,...`).
Responde a RNF-16 Integridad de datos: la base rechaza los valores inválidos en
lugar de truncarlos en silencio, lo que importa cuando se descuenta stock.

**`innodb_lock_wait_timeout = 10`.** El registro de una venta (CUS-04) bloquea las
filas de los productos con `SELECT ... FOR UPDATE`. Si otra transacción retiene el
bloqueo, la espera no debe ser indefinida.

**Zona horaria `America/Lima` en los tres sitios** — PHP, MySQL y el contenedor.
RNF-08 exige registrar la fecha y la hora de cada venta, y el número de factura
correlativo se genera por día.

**`bcmath` está instalada.** El cálculo del subtotal, el IGV del 18 % y el total
(RF-11) usa decimales; hacerlo con coma flotante produce descuadres de céntimos.

**OPcache con `validate_timestamps = 1`.** En desarrollo los cambios en el código
se ven sin reiniciar el contenedor. Para producción hay que ponerlo en 0.

---

## Lista de comprobación del entorno

Ejecútela después de instalar y adjunte la evidencia al Hito 1.

| # | Comprobación | Comando | Resultado esperado |
|---|---|---|---|
| 1 | Los cuatro contenedores están arriba | `docker compose ps` | 4 servicios en estado `running`; `db` como `healthy` |
| 2 | Nginx responde | `curl -I http://localhost:8080` | `HTTP/1.1 200 OK` |
| 3 | La aplicación carga | Abrir <http://localhost:8080> | Pantalla de bienvenida de Laravel |
| 4 | PHP tiene las extensiones | `docker compose exec app php -m` | Aparecen `pdo_mysql`, `mbstring`, `bcmath`, `gd`, `zip` |
| 5 | Laravel ve la base de datos | `docker compose exec app php artisan migrate:status` | Lista de migraciones, sin error de conexión |
| 6 | Las tablas existen | `docker compose exec db mysql -uferremax -pferremax -e "SHOW TABLES" ferremax` | Tablas de Laravel creadas |
| 7 | phpMyAdmin entra | Abrir <http://localhost:8081> | Panel con la base `ferremax` |
| 8 | Los datos persisten | `docker compose down && docker compose up -d` | Las tablas siguen ahí |
| 9 | La base no está expuesta | `curl -sS telnet://localhost:3306` | Conexión rechazada |
| 10 | La zona horaria es correcta | `docker compose exec app php -r "echo date('Y-m-d H:i T');"` | Hora de Lima (`-05`) |

---

## Problemas frecuentes

**«port is already allocated» al levantar.** Otro programa usa el 8080 o el 8081.
Cambie `APP_PORT` o `PMA_PORT` en `.env` y vuelva a ejecutar `make up`.

**«Permission denied» al escribir en `storage/`.** El UID del contenedor no coincide
con el suyo. Corrija `UID` y `GID` en `.env` con el resultado de `id -u` e `id -g`,
y reconstruya con `docker compose build --no-cache app`.

**«SQLSTATE[HY000] [2002] Connection refused».** MySQL todavía estaba arrancando.
Espere a que `docker compose ps` muestre `db` como `healthy` y repita el comando.

**Los cambios en el código no se reflejan.** Limpie la caché de configuración:
`docker compose exec app php artisan optimize:clear`.

**Windows: el arranque es muy lento.** Mueva el proyecto dentro del sistema de
archivos de WSL2 (`\\wsl$\Ubuntu\home\...`) en lugar de `C:\`. El montaje de
volúmenes entre Windows y WSL es el cuello de botella.

---

## Convenciones del repositorio

Ramas de trabajo, una por caso de uso:

```
main                 versiones liberadas (protegida)
develop              integración
feature/c01 … c09    un caso de uso por rama
```

Formato de los mensajes de commit:

```
tipo(caso): descripción breve en presente

feat(c04): calcular el IGV en VentaService
fix(c03): impedir el borrado de productos con ventas asociadas
docs(c09): actualizar la especificación de reportes
```
